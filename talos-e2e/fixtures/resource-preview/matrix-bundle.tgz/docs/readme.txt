TGZ archive member preview: 42
