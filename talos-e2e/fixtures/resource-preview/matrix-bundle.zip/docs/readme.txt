ZIP archive member preview: 42
