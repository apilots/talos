TAR archive member preview: 42
