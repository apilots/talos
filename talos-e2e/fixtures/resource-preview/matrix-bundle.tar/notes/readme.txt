TAR notes member: a different file with the same basename
